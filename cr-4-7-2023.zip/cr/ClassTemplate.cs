﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCSMarkingDLL.cr
{
    class ClassTemplate
    {

        public static String getCR0()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }


        public static String getCR1()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR2()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR3()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCR4()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR5()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR6()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR7()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCR8()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCR9()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRA()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRB()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRC()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRD()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRE()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRF()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRG()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRH()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRI()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRJ()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRK()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRL()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRM()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRN()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRO()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRP()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRQ()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRR()
        {
            StringBuilder sb = new StringBuilder();



            return sb.ToString();
        }

        public static String getCRS()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRT()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRU()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRV()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRW()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRX()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRY()
        {
            StringBuilder sb = new StringBuilder();



            return sb.ToString();
        }

        public static String getCRZ()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }


        //========== special chars ==============

        public static String getCRCOLON()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRCR()
        {
            StringBuilder sb = new StringBuilder();



            return sb.ToString();
        }

        public static String getCRCOMMA()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRDOT()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRFOOTER()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        public static String getCRHASH()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRHEADER()
        {
            StringBuilder sb = new StringBuilder();



            return sb.ToString();
        }

        public static String getCRSLASH()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }


        public static String getCRAMP()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRSPACE()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

        public static String getCRHYPHEN()
        {
            StringBuilder sb = new StringBuilder();


            return sb.ToString();
        }

    }
}
