﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCSMarkingDLL.cr
{
    public class Consts
    {
        //0.250
        //0.125
        // 0.19
        //0.090

        public static string P250 = "0.250";
        public static string P125 = "0.125";
        public static string P19 = "0.19";
        public static string P090 = "0.090";

        //return CMON.getHEADER(pstr, Consts.P125);
    }
}
